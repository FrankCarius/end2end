## Graph-VM: version 1.00           ##
## Build by: Bouke Groenescheij     ##

Hi, welcome to the VM-Graph script.

This script grabs an 'x' amount of statistics from 'y' amount of vCenter servers for 'z' amount of VMs.

Three files are used for this, all .csv:

x - MetricsVM.csv and MetricsHOST.csv

Enter "MetricId","Pct","Description"
1. Do not remove the first line!!!
2. Available MetricId for your VM/Host can be found by using:
	connect-viserver <vCenter Server>
	Get-StatType -Entity (Get-VM "<one of your VMs>") -Interval "Past Day"
	Get-StatType -Entity (Get-VMHost "<one of your Hosts>") -Interval "Past Day"
3 Pct is either empty (so it won't calculate the % of the Metric stats), a value (the max possible for that stat) or an formula to calculate the PCT where needed. Example: [Math]::round((Get-vmhost $Entity.HostFQDN | Get-View).Hardware.CpuInfo.Hz / 100000000 / $Entity.NumCPU , 2) - this calculates the MHz, nice for the MHz stat.
4 Description: HTML formatted text to add after each graph.


y - vCenterServers.csv

Enter "name","user","password"
1. Do not remove the first line!!!
2. "name" = vCenter name
3. "user" = user used to log onto that server - a readonly is recommended, password is in clear text
4. "password" = password to log onto that server with that user


z - ToBeReported.csv
Enter "name"
1. Do not remove the first line!!!
2. list each VM to be reported on it's own line - the script does all the work for you.

Did I say not to remove the first line from the '.csv' files? It will screw the scrip ;-)

The script uses RRDTOOL.EXE to create an table and plot the graph. It's easy and free, and doesn't need any installing.
Download from here: http://oss.oetiker.ch/rrdtool/download.en.html and grab version 1.3 from the contrib folder
However I've found version 1.2.30 much faster and this link also has the correct fonts in the zip: http://www.gknw.de/mirror/rrdtool/rrdtool-1.2.30-bin-w32.zip
You'll need the Native Windows package. It's recommended to extract to an directory, and add that directory to the %PATH% environment variable.
To test if it works from Powershell, just execute '& rrdtool'.
Also install the fonts into your Windows fonts folder (the DejaVuSansMono-Roman.ttf)

OUTPUT:
All output just goes to the 'report folder' (change the variable if needed). It's removed if it is still there, else a new folder is created. Check the scripts, it's not rocket science.


- CREDITS -
Special credits goes to LucD who runs an *excellent* blog on powershell. More info about performance stats in PowerShell can be found here:
http://www.lucd.info/2009/12/30/powercli-vsphere-statistics-part-1-the-basics/

And also to Tobi Oetiker for hosting and maintaining the rrdtool scripts.


Cheers and have fun!!!

Regards,
Bouke Groenescheij
bouke@jume.nl
http://www.jume.nl/blog
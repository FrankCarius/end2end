﻿## Graph-VM: version 1.00           ##
## Build by: Bouke Groenescheij     ##
## Please read: README.txt for info ##
## This File is used for all HTML Functions

function WriteHTMLHeader
{param ($file, $title, $style)
'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' | Out-File "${file}" -Append
'<html xmlns="http://www.w3.org/1999/xhtml">' | out-file "${file}" -Append
'<head>' | out-file "${file}" -Append
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <title>'+${title}+'</title> <link rel="stylesheet" href="'+${style}+'" type="text/css" /> </head>' | out-file "${file}" -Append
'<body leftmargin="0" marginwidth="0">' | out-file "${file}" -Append
}

function WriteComment
{param ($file, $comment)
'<!-- '+${comment}+' -->' | out-file "${file}" -Append
}

function WriteHTMLFooter
{param ($file)
'</body>' | out-file "${file}" -Append
'</html>' | out-file "${file}" -Append
}

function WriteChapter
{param ($file, $text)
'<h1>'+${text}+'</h1>' | out-file "${file}" -Append
}

function WriteP
{param ($file, $text)
'<p>'+${text}+'</p>' | out-file "${file}" -Append
}

function FormatLink
{param ($text, $link)
'<a href="'+${link}+'">'+${text}+'</a>'
}

function InsertImage
{param ($file, $image)
'<p><img src="'+${image}+'"></p>' | out-file "${file}" -Append
}


#### Table Functions

function WriteTableOpen
{param ($file)
'<table><tr>' | out-file "${file}" -Append
}

function WriteTableHeader
{param ($file, $text)
'<th scope="col">'+${text}+'</th>' | out-file "${file}" -Append
}

function WriteTableCell
{param ($file, $text)
'<td>'+${text}+'</td>' | out-file "${file}" -Append
}

function WriteTableRow
{param ($file)
'</tr><tr>' | out-file "${file}" -Append
}

function WriteTableClose
{param ($file)
'</tr></table>' | out-file "${file}" -Append
}

#### Div Functions

function WriteDivOpen
{param ($file, $class, $id)
$completediv = '<div'
if ($class) {$completediv += ' class="'+${class}+'"'}
if ($id) {$completediv += ' id="'+${id}+'"'}
$completediv += '>'
$completediv | Out-File "${file}" -Append
}

function WriteDivClose
{param ($file)
'</div>' | out-file "${file}" -Append
}
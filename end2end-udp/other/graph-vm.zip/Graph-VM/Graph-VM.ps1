﻿## Graph-VM: version 1.00           ##
## Build by: Bouke Groenescheij     ##
## Please read: README.txt for info ##

$ScriptStartTime = get-date
Clear-Host
#VM Report: This script creates a detailed report for VMs from the last three days
Write-Host "Getting data from files and setting variables" -NoNewline
$ToBeReported = Import-Csv ".\ToBeReported.csv"
$vCenterServers = Import-Csv ".\vCenterServers.csv"
$RequestedMetricsVM = Import-Csv ".\MetricsVM.csv"
$RequestedMetricsHost = Import-Csv ".\MetricsHOST.csv"

# File Locations (this can be left to default) - be aware that previous reports are overwritten!
$ReportDIR = ".\Report"

# Static Variables
# The counters requested. Whole available list can be requested using: 
$StatsVM = $RequestedMetricsVM | select MetricId | %{$_.MetricId}
$StatsHost = $RequestedMetricsHost | select MetricId | %{$_.MetricId}
$Colors = "#555C74","#C5555D","#D5964A","#727B7F","#7CAB52","#8663A6","#6393C6","#EFCF5A","#B0B1B2","#744F3B","#2D2417","#A09C92","#555C74","#C5555D","#D5964A","#727B7F","#7CAB52","#8663A6","#6393C6","#EFCF5A","#B0B1B2","#744F3B","#2D2417","#A09C92"	#The same colors VMware is using, change to your own liking.

# Include functions
. ".\HTMLFunctions.ps1"
. ".\RRDFunctions.ps1"
# Include done
Write-Host " - [DONE]"

# Get the info needed for the tables. This info is later used a info to grab the usage counter.
Write-Host "Connecting to vCenters for VMs" -NoNewline
$VMsTable = @()
foreach ($vCenterServer in $vCenterServers)
{
  $LastConnectedvCenter = Connect-VIServer $vCenterServer.name -User $vCenterServer.user -Password $vCenterServer.password -WarningAction SilentlyContinue
  foreach ($VM in $ToBeReported)
  {
	$VMDetails = Get-VM -Name $VM.name -ErrorAction SilentlyContinue
    if ($VMDetails) 
	{
      $ThisRow = "" | select name,vCenter,NumCPU,MemoryMB,OSFullName,Host,HostFQDN,DataStore
	  $ThisRow.name = $VMDetails.name
	  $ThisRow.vCenter = $vCenterServer.name
	  $ThisRow.NumCPU = $VMDetails.NumCpu
	  $ThisRow.MemoryMB = $VMDetails.MemoryMB
	  $ThisRow.OSFullName = $VMDetails.Guest.OSFullName
	  $ThisRow.Host = $VMDetails.Host.Name.Split(".")[0]
	  $ThisRow.HostFQDN = $VMDetails.Host.Name
	  $ThisRow.DataStore = $VMDetails.HardDisks[0].Filename.Split("]")[0].remove(0,1)
	  $VMsTable += $ThisRow
	}
  }
  Disconnect-VIServer -Confirm:$False
}
$VMsTable = $VMsTable | Sort-Object vCenter,name
$HOSTsTable = $VMsTable | Sort-Object Host -unique
Write-Host " - [DONE]"

# Check ReportDIR, recreate if existing, create if not-existing
if ((Test-Path $ReportDIR) -eq $true) {del $ReportDIR -recurse > $null ;md $ReportDIR > $null}
else {md $ReportDIR > $null}

# Create the folders, HTML files and RRD Tables
$Index = ".\Report\index.html"
cp ".\style.css" ".\Report\." > $null

WriteHTMLHeader $Index "Resource Report Overview" "style.css"
WriteChapter $Index "Resource Report Overview"
$Text = "This report consists of "+$ToBeReported.Count+" VM(s). Review the table below and click each VM to show the detailed report."
WriteP $Index $Text

WriteTableOpen $Index
WriteTableHeader $Index "VM"
WriteTableHeader $Index "vCenter"
WriteTableHeader $Index "# CPU(s)"
WriteTableHeader $Index "Memory #"
WriteTableHeader $Index "Guest OS"
WriteTableHeader $Index "Host"
WriteTableHeader $Index "Datastore"

Function CreateEverything ($f_Entity, $f_Entity_Type)
{
  ####################################################################################
  if ($f_Entity_Type -eq "VM") {$l_EntityName = $Entity.name} else {$l_EntityName = $Entity.Host}
    
  Write-Host "=== Working on $($Entity_Type): $($l_EntityName) ==="
  
  if ($f_Entity_Type -eq "VM")
  {
    WriteTableRow $Index
    $Link = FormatLink -link "$($l_EntityName)/index.html" -text "$($l_EntityName)"
    WriteTableCell $Index $Link
    WriteTableCell $Index ($vmstable |? {$_.name -eq $($l_EntityName)}).vCenter
    WriteTableCell $Index ($vmstable |? {$_.name -eq $($l_EntityName)}).NumCPU
    WriteTableCell $Index (""+($vmstable |? {$_.name -eq $($l_EntityName)}).MemoryMB+" MB")
    WriteTableCell $Index ($vmstable |? {$_.name -eq $($l_EntityName)}).OSFullName
    $thehost = ($vmstable |? {$_.name -eq $($l_EntityName)}).Host
    $Link = FormatLink -link "$($thehost)/index.html" -text $thehost
    WriteTableCell $Index $Link
    WriteTableCell $Index ($vmstable |? {$_.name -eq $($l_EntityName)}).DataStore
  }
  
  md "${ReportDIR}\$($l_EntityName)" > $null
  $EntityIndex = "${ReportDIR}\$($l_EntityName)\index.html"
  writeHTMLHeader $EntityIndex $($l_EntityName) "../style.css"
  $Text = "Detailed report for "+$($l_EntityName)+"."
  writeChapter $EntityIndex $Text
  
  $RRDFile = "${ReportDIR}\$($l_EntityName)\data.rrd"
  $RRDGraph = $RRDFile.replace(":","\:")
  
  Write-Host "Connecting to vCenter" -NoNewline
  if ($f_Entity_Type -eq "VM") {$ThevCenterServer = ($vmstable | ?{$_.name -eq $l_EntityName}).vcenter} else {$ThevCenterServer = ($hoststable | ?{$_.Host -eq $l_EntityName}).vcenter}
  $ThevCenterUsername = ($vCenterServers | ?{$_.name -eq $ThevCenterServer}).user
  $ThevCenterPassword = ($vCenterServers | ?{$_.name -eq $ThevCenterServer}).password
  $LastConnectedvCenter = Connect-VIServer $ThevCenterServer -User $ThevCenterUsername -Password $ThevCenterPassword -WarningAction SilentlyContinue
  Write-Host " - [DONE]"
  
  Write-Host "Getting the $($f_Entity_Type) details" -NoNewline
  if ($f_Entity_Type -eq "VM") {$TheEntity = Get-VM $l_EntityName} else {$TheEntity = Get-VMHost $Entity.HostFQDN}
  Write-Host " - [DONE]"

  # The OFS variable defines the character between the array string (Output Field Seperator)
  $OFS=" "

  # Since we do not know how many days are saved, we need to grab the StorageTimeSecs for "Past Day" to grab them all...
  Write-Host "Getting available statistics interval" -NoNewline
  $StatInterval = Get-StatInterval | ?{$_.Name -eq "Past Day"}
  $SamplingPeriod = $StatInterval.SamplingPeriodSecs  # This should result in 300 (thats 5 minutes dude ;-))
  $StorageTimeSecs = $StatInterval.StorageTimeSecs  # Now together with the amount of seconds stored, we can calculate the amount of days we can plot.
  $StoredDays = $StorageTimeSecs / 60 / 60 / 24  # Should work ;-)
  
  $MaxSamples = $StorageTimeSecs / $SamplingPeriod
  
  $SamplingPeriodPct = $SamplingPeriod * 10  # This variable is used to calculate the % for the RRD graph. We print the amount of % and is dependent on the amount of samplingseconds. The value we get is milliseconds so it's * 10 to get the % in seconds ;-)
  Write-Host " - [DONE]"

  # But first grab all the stats:
  Write-Host "Getting the statistics" -NoNewline
  if ($f_Entity_Type -eq "VM") {$stats = $StatsVM } else {$stats = $StatsHost} 
  $AllStatValues = Get-Stat -entity $TheEntity -Stat $stats -MaxSamples $MaxSamples -IntervalMins ($SamplingPeriod / 60) -ErrorAction SilentlyContinue
  # Since the IntervalMins is in minutes we divide by 60 - 60 secs in a min hey hey, and the erroraction is to clean up counters which don't exist
  Write-Host " - [DONE]"
  
  Write-Host "Grouping the statistics into timestamp" -NoNewline
  $GroupedStats = $AllStatValues | Group-Object Timestamp
  Write-Host " - [DONE]"
  
  Write-Host "Reverse the statistics object" -NoNewline
  [array]::Reverse($GroupedStats)
  Write-Host " - [DONE]"

  # The instance is a odd thing. Some counters have a value for the instance, others nothing to even names or ids. However, we need to know
  # which instances are available so we can use all values in the RRD Graph. The InstancesTable is a table which is used throughout the whole
  # script to match counters and use names in the graph etc.
  Write-Host "Creating a temp Table with the instance details" -NoNewline
  $AllInstances = $GroupedStats[0].group 		# Instance is used for this
  $NumInstances = $AllInstances.Count
  Write-Host " - [DONE]"

  Write-Host "Creating Instance Table" -NoNewline
  $InstancesTable = @()
  $Id = 0
  foreach ($ThisInstance in $AllInstances)
  {
    $ThisRow = "" | select Id, MetricId, Unit, Description, Entity, Instance
    $ThisRow.Id = $Id
    $ThisRow.MetricId = $ThisInstance.MetricId
    $ThisRow.Unit = $ThisInstance.Unit
    $ThisRow.Description = $($ThisInstance.Description).split(".")[0]
    $ThisRow.Entity = $ThisInstance.Entity
    $ThisRow.Instance = $ThisInstance.Instance
    $InstancesTable += $ThisRow
    $Id += 1
  }
  Write-Host " - [DONE]"

  # The next part is setting the dates and unixtimes. We want to plot everything which is available to "Daily stats"
  Write-Host "Creating the rrd file" -NoNewline	
  $FirstDateForRRD = (Get-Date $GroupedStats[0].Values[0].addminutes(-5) -UFormat %s).split(",")[0]
  CreateRRD -f_Filename $RRDFile -f_StartTime $FirstDateForRRD -f_Instances $InstancesTable -f_Step $SamplingPeriod -f_DSTArguments $StorageTimeSecs -f_Samples $MaxSamples
  Write-Host " - [DONE]"
  
  Write-Host "Updating RRD table with values" -NoNewline	
  $OFS=":"
  $GroupedStats | %{
						$UnixTime = (Get-Date $_.Name -UFormat %s).split(",")[0]
 						$_.Group | % {$StatValues += @($_.Value)}
						$FullArguments = "${UnixTime}:${StatValues}"
						& rrdtool update $rrdfile $FullArguments
						$StatValues = @()
					  }
  Write-Host " - [DONE]"
  
  Write-Host "Creating Graphs" -NoNewline
  [int]$LastDateForRRD = [int]$UnixTime+$SamplingPeriod
  
  if ($f_Entity_Type -eq "VM") {$TheRequestedMetrics = $RequestedMetricsVM } else {$TheRequestedMetrics = $RequestedMetricsHost }
  
  createrrdgraph -f_Colors $Colors -f_EndTime $LastDateForRRD -f_Entity $TheEntity -f_Height 420 -f_ReportDIR $ReportDIR -f_RequestedMetrics $TheRequestedMetrics -f_rrdgraph $RRDGraph -f_StartTime $FirstDateForRRD -f_Table $InstancesTable -f_TheStats $Stats -f_Type $f_Entity_Type -f_Width 1140  
  Write-Host "Creating Graphs - [DONE]"

  writeHTMLFooter $EntityIndex
  Disconnect-VIServer -Confirm:$False

  ####################################################################################
}

foreach ($Entity in $VMsTable)
{
  CreateEverything -f_Entity $Entity -f_Entity_Type "VM"
}

foreach ($Entity in $HOSTsTable)
{
  CreateEverything -f_Entity $Entity -f_Entity_Type "HOST"
}

Write-Host "Closing HTML files" -NoNewline
writeTableClose $Index
writeDivOpen $Index -class "footer"
$ReadyTime = get-date
$ElapsedTime = $ReadyTime - $ScriptStartTime 
$Text = "Report Generated on: "+(get-date)+" - total generation time: "+[Math]::round($ElapsedTime.TotalSeconds,0)+" seconds."
writeP $Index $Text
writeDivClose $Index
writeHTMLFooter $Index
Write-Host " - [DONE]"

#Open the newly generated index.html in the report directory. Allow the viewing of our cool report :-)
Write-Host "Opening Report in Internet Explorer" -NoNewline
$ie = new-object -comobject "InternetExplorer.Application"
$ie.visible = $true
$ie.navigate("$PWD\$ReportDIR\index.html")
Write-Host " - [DONE]"
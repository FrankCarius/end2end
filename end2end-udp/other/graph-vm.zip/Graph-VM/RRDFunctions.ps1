﻿## Graph-VM: version 1.00           ##
## Build by: Bouke Groenescheij     ##
## Please read: README.txt for info ##
## This File is used for all RRD Functions

function CreateRRD ($f_Filename, $f_StartTime, $f_Instances, $f_Step, $f_DSTArguments, $f_Samples)
{
  $l_rrdrra = "RRA:MAX:0.5:1:${f_Samples}"
  $l_rrdds = @()
  foreach ($l_Instance in $f_Instances)
  {
    $l_ds = $l_Instance.Id
    $l_rrdds += "DS:${l_ds}:GAUGE:${f_DSTArguments}:0:U"
  }
  & rrdtool create $f_Filename --start $f_StartTime --step $f_Step $l_rrdds $l_rrdrra 
}

function Get-Ids ($f_Table, $f_MetricId)
{
  return ($f_Table | ?{$_.MetricId -eq $f_MetricId} | %{$_.Id})
}

function createrrdgraph ($f_Entity, $f_Type, $f_TheStats, $f_RequestedMetrics, $f_Table, $f_StartTime, $f_EndTime, $f_rrdgraph, $f_Width, $f_Height, $f_Colors, $f_ReportDIR)
{
  foreach ($l_Stat in $f_TheStats)
  {
    $OFS=" "
	$l_ds = $l_Stat.replace(".","")
	$l_Label = $l_Stat.split(".")[0]
	$l_title = @($f_Table | ?{$_.MetricId -eq $l_Stat})[0].Description
	$l_vlabel = @($f_Table | ?{$_.MetricId -eq $l_Stat})[0].Unit
	
  	# Getting the % is important to relitivate the counters. Some can be calculated, some are dependent on the capable hardware, so you need to find that out yourself.
	if ($f_Type -eq "HOST") {$l_ESXHostView = Get-vmhost $f_Entity | Get-View}
	$l_Expression = (($f_RequestedMetrics | ?{$_.MetricId -eq $l_Stat}).PCT)
	if ($l_expression) {$l_Pct = Invoke-Expression $l_Expression}
	else {$l_Pct = ""}
	  
	$l_definitions = @()
	$l_vdefinition = @()
    $l_lines = @()
	
	if ($f_Type -eq "VM") {$l_lines += 'COMMENT:VM\: '+${f_Entity}+'\j'}
	else {$l_lines += 'COMMENT:HOST\: '+${f_Entity}+'\j'}
	
	# Now grab the Ids and throw that array into definitions and lines
	$l_TheIds = get-Ids -f_Table $f_Table -f_MetricId $l_Stat
	
	$l_jj = 0
    foreach ( $l_ii in $l_TheIds )
    {
	  $l_Instance = ($f_Table | ?{$_.Id -eq $l_ii}).Instance
      $l_definitions += 'DEF:D'+${l_ii}+'='+$f_rrdgraph+':'+${l_ii}+':MAX'
	  $l_vdefinition += 'VDEF:V'+${l_ii}+'MAX=D'+${l_ii}+',MAXIMUM'
  	  $l_vdefinition += 'VDEF:V'+${l_ii}+'MIN=D'+${l_ii}+',MINIMUM'
  	  $l_vdefinition += 'VDEF:V'+${l_ii}+'AVE=D'+${l_ii}+',AVERAGE'
	  if ($l_Pct) 
      {
        $l_vdefinition += 'CDEF:C'+${l_ii}+'MAXPCT=D'+${l_ii}+','+$l_Pct+',/'
	    $l_vdefinition += 'CDEF:C'+${l_ii}+'MINPCT=D'+${l_ii}+','+$l_Pct+',/'
	    $l_vdefinition += 'CDEF:C'+${l_ii}+'AVEPCT=D'+${l_ii}+','+$l_Pct+',/'
	  }  
     
    $l_lines += 'LINE1:D'+${l_ii}+${f_colors}[$l_jj]+':'+${l_Label}+' '+${l_Instance}.Replace(":","\:")
	$l_lines += 'GPRINT:V'+${l_ii}+'MAX: Maximum\: %5.0lf'
	if ($l_Pct){$l_lines += 'GPRINT:C'+${l_ii}+'MAXPCT:MAX: MaximumPct\: %2.2lf'}
	$l_lines += 'GPRINT:V'+${l_ii}+'AVE: Average\: %5.0lf'
	if ($l_Pct){$l_lines += 'GPRINT:C'+${l_ii}+'AVEPCT:AVERAGE: AveragePct\: %2.2lf'}
	$l_lines += 'GPRINT:V'+${l_ii}+'MIN: Minimum\: %5.0lf'
	if ($l_Pct){$l_lines += 'GPRINT:C'+${l_ii}+'MINPCT:MIN: MinimumPct\: %2.2lf'}
	$l_lines += 'COMMENT:\j'
	$l_jj += 1
    }
	if ($f_Type -eq "VM") {$l_EntityName = $f_Entity} else {$l_EntityName = $f_Entity.Name.Split(".")[0]}
    $l_outputfile = "${f_ReportDIR}\${l_EntityName}\${l_ds}.png"
    & rrdtool graph -s ${f_starttime} -e ${f_endtime} ${l_outputfile} ${l_definitions} ${l_vdefinition} ${l_lines} -l 0 -E -t ${l_title} -w ${f_width} -h ${f_height} --vertical-label ${l_vlabel} > $null
  
    $l_HTMLFile = "${f_ReportDIR}\${l_EntityName}\index.html"
  
    InsertImage -file $l_HTMLFile -image "${l_ds}.png"
    $l_GraphDescription = ($f_RequestedMetrics | ?{$_.MetricId -eq $l_Stat}).Description
    WriteP $l_HTMLFile $l_GraphDescription
    $l_Comment = "############# ^^^ ADD MORE INFO ABOUT ${l_Stat} ^^^ #############"
    WriteComment $l_HTMLFile "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"
    WriteComment $l_HTMLFile $l_Comment
    WriteComment $l_HTMLFile ""
	  	  
    WriteP $l_HTMLFile "&nbsp;"
  }
}
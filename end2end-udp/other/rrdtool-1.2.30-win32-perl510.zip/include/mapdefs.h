#ifndef _MAPDEFS_H
#define _MAPDEFS_H

/* Definition mappings for Windows <=> UNIX */

/* Constants */

#endif
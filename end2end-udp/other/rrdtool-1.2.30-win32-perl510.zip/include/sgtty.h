#ifndef _SGTTY_H
#define _SGTTY_H

#endif
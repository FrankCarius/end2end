#ifndef _IN_H
#define _IN_H

/* As found in UNIX - identifies data to/from the loopback address */
#define	IN_LOOPBACKNET		127

#endif
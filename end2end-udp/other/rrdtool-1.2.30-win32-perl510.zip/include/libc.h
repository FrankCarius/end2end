#ifndef _LIBC_H
#define _LIBC_H

#include <sys/socket.h>


#endif
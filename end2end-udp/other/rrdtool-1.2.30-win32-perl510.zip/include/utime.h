#ifndef _UTIME_H
#define _UTIME_H

#include <sys/utime.h>
#define utime _utime
#define utimbuf _utimbuf

#endif

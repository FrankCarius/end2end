#ifndef _BSAFE_LINK_H
#define _BSAFE_LINK_H

#endif
#ifndef IOCTL_H
#define IOCTL_H		1

/* Dummy include for Windows NT */

#endif
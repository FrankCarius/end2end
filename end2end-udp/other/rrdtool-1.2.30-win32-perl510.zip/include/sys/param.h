#ifndef PARAM_H
#define PARAM_H		1

/* Dummy include for Windows NT */

#endif
#ifdef  __cplusplus
extern "C" {
#endif

struct stats_values {				// linked data where stats put its results
	union {							// VALUES OF THESE DATA
		void * ptr;					// when this is a list, pointer to a memory block containing the list
		int i;						// for single value data : integer
		double d;					//						double
		char * str;					//						string
	} val;
	int	nbvals;						// if =0, single value, else list
	char * format;					// how does rrdtool print that
	char datatype;					// data type (i/d/s, uppercase for lists)
	struct stats_values * pnext;	// ptr to next one
} stats_values;
int rrd_stats (int argc, char **argv, struct stats_values ** psv);
void free_psv ( struct stats_values * psv );

#ifdef  __cplusplus
}
#endif

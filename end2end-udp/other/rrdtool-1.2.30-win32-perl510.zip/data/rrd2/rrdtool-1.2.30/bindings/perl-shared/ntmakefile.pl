use ExtUtils::MakeMaker;
use Config;
# See lib/ExtUtils/MakeMaker.pm for details of how to influence
# the contents of the Makefile that is written.
# Run VCVARS32.BAT before generating makefile/compiling.
WriteMakefile(
    'NAME'	=> 'RRDs',
    'VERSION_FROM' => 'RRDs.pm',
#    'DEFINE'	   => "-DPERLPATCHLEVEL=$Config{PATCHLEVEL}",
# keep compatible w/ ActiveState 5xx builds
	'DEFINE'		=> "-DPERLPATCHLEVEL=5 -D_WIN32",

	'OPTIMIZE' => '-O2',
	'LIBC' => 'libc.lib',
	'LDLOADLIBS' =>   'oldnames.lib kernel32.lib user32.lib gdi32.lib winspool.lib  comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib  netapi32.lib uuid.lib wsock32.lib mpr.lib winmm.lib  version.lib odbc32.lib odbccp32.lib libc.lib',
	'MYEXTLIB'  => join (' ',
		'../../release/rrd.lib',
		'../../../freetype-2.1.9/objs/freetype219ST.lib',
		'../../../cgilib-0.5/release/cgilib-0.5.lib',
		'../../../libart_lgpl-2.3.17/release/libart_lgpl-2.3.17.lib',
		'../../../libpng-1.2.5/release/libpng-1.2.5.lib',
		'../../../zlib-1.2.1/release/zlib-1.2.1.lib',
		),
#	'MYEXTLIB'  => join (' ',
#		'../../debug/rrd.lib',
#		'../../../freetype-2.1.9/objs/freetype219ST_D.lib',
#		'../../../cgilib-0.5/Debug/cgilib-0.5.lib',
#		'../../../libart_lgpl-2.3.17/Debug/libart_lgpl-2.3.17.lib',
#		'../../../libpng-1.2.5/Debug/libpng-1.2.5.lib',
#		'../../../zlib-1.2.1/Debug/zlib-1.2.1.lib',
#		),
		#'-Llibc.lib',
		#'-oldnames.lib',
    'realclean'    => {FILES => 't/demo?.rrd t/demo?.png' },
    ($] ge '5.005') ? (
        'AUTHOR' => 'Tobias Oetiker (oetiker@ee.ethz.ch)',
        'ABSTRACT' => 'Round Robin Database Tool',
    ) : ()

);

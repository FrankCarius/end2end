param (
	$wert="1"
)

write-host "Root $($wert)"



function test ($wert) {
	write-host "Sub $($wert)"
}

test

write-host "Root $($wert)"